from django.urls import path
from lab31.views import registerAJ, searchAJ, search_page

urlpatterns = [
    path('registerAJ/', registerAJ),
    path('searchAJ/', searchAJ),
    path('', search_page, name='search_page'),  
]
