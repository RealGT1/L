from django.apps import AppConfig


class Lab22Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lab22'
