from django.contrib import admin
from lab22.models import Students, Course

admin.site.register(Students)
admin.site.register(Course)
