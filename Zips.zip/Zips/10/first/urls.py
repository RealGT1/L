from django.urls import path
from lab22.views import StudentListView, StudentDetailView

urlpatterns = [
   path('student_list/',StudentListView.as_view()),
   path('student_list/student_detail/<int:pk>/',StudentDetailView.as_view()),
]
