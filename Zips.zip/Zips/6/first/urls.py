from django.contrib import admin
from django.urls import path
from lab21.views import aboutus, home, contactus

urlpatterns = [
    path('home/',home),
    path('about/',aboutus),
    path('contact/',contactus),
]
