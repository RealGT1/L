from django.urls import path
from lab22.views import download, generate_pdf

urlpatterns = [
   path('download/',download),
   path('generate_pdf_file/',generate_pdf),
]
