from django.contrib import admin
from django.urls import path
from lab22.views import register, viewstudent, displaystudents

urlpatterns = [
    path('admin/', admin.site.urls),
    path('register/',register),
    path('viewstudent/',viewstudent),
    path('viewstudent/displaystudents/',displaystudents),
]