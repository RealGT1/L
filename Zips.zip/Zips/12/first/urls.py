from django.urls import path
from lab31.views import registerAJ
urlpatterns = [
path('registerAJ/',registerAJ),
]
