from django.contrib import admin
from django.urls import path
from lab21.views import show_list
urlpatterns = [
path('admin/', admin.site.urls),
path('showlist/',show_list),
]