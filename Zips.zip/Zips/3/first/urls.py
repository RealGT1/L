from django.contrib import admin
from django.urls import path
from lab3.views import current_datetime
urlpatterns = [
path('cdt/', current_datetime),
]